#ifndef RTW_HEADER_UAV_Test_capi_h_
#define RTW_HEADER_UAV_Test_capi_h_
#include "UAV_Test.h"
extern void UAV_Test_InitializeDataMapInfo ( void ) ;
#endif
