#include "UAV_Test.h"
#include "UAV_Test_types.h"
#include "rtwtypes.h"
#include <string.h>
#include "mwmathutil.h"
#include <math.h>
#include "UAV_Test_private.h"
#include "rt_logging_mmi.h"
#include "UAV_Test_capi.h"
#include "UAV_Test_dt.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 3 , & stopRequested ) ; }
rtExtModeShutdown ( 3 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 0 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 0 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 1 ; int_T gbl_raccel_NumST = 4 ; const char_T
* gbl_raccel_Version = "10.7 (R2023a) 19-Nov-2022" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes (
SimStruct * S , const char * inportFileName , int * matFileFormat ) { return
rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
#define klxv1hydll (-1)
B rtB ; X rtX ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS =
& model_S ; static void pvjunuhwfs ( ncubee03tu * obj ) ; static real_T
eyukbmfsyx ( const real_T x [ 3 ] ) ; static void pvjunuhwfs ( ncubee03tu *
obj ) { obj -> ModelImpl . Configuration . PHeight = 3.9 ; obj -> ModelImpl .
Configuration . PFlightPathAngle = 39.0 ; obj -> ModelImpl . Configuration .
PAirSpeed = 1.0 ; obj -> ModelImpl . Configuration . PDRoll [ 0 ] = 5.9414 ;
obj -> ModelImpl . Configuration . FlightPathAngleLimits [ 0 ] = -
0.52359877559829882 ; obj -> ModelImpl . Configuration . PDRoll [ 1 ] = 3.9 ;
obj -> ModelImpl . Configuration . FlightPathAngleLimits [ 1 ] =
0.52359877559829882 ; } static real_T eyukbmfsyx ( const real_T x [ 3 ] ) {
real_T absxk ; real_T scale ; real_T t ; real_T y ; scale =
3.3121686421112381E-170 ; absxk = muDoubleScalarAbs ( x [ 0 ] ) ; if ( absxk
> 3.3121686421112381E-170 ) { y = 1.0 ; scale = absxk ; } else { t = absxk /
3.3121686421112381E-170 ; y = t * t ; } absxk = muDoubleScalarAbs ( x [ 1 ] )
; if ( absxk > scale ) { t = scale / absxk ; y = y * t * t + 1.0 ; scale =
absxk ; } else { t = absxk / scale ; y += t * t ; } absxk = muDoubleScalarAbs
( x [ 2 ] ) ; if ( absxk > scale ) { t = scale / absxk ; y = y * t * t + 1.0
; scale = absxk ; } else { t = absxk / scale ; y += t * t ; } return scale *
muDoubleScalarSqrt ( y ) ; } void MdlInitialize ( void ) { memcpy ( & rtX .
dxenv44p1n [ 0 ] , & rtP . Integrator_IC [ 0 ] , sizeof ( real_T ) << 3U ) ;
rtDW . a5dgdf4x33 = klxv1hydll ; rtDW . cewk5aac1w = 0U ; rtDW . a1y4rhv5lu .
OutputTemplate . North = 0.0 ; rtDW . a1y4rhv5lu . OutputTemplate . East =
0.0 ; rtDW . a1y4rhv5lu . OutputTemplate . Height = 0.0 ; rtDW . a1y4rhv5lu .
OutputTemplate . AirSpeed = 0.0 ; rtDW . a1y4rhv5lu . OutputTemplate .
HeadingAngle = 0.0 ; rtDW . a1y4rhv5lu . OutputTemplate . FlightPathAngle =
0.0 ; rtDW . a1y4rhv5lu . OutputTemplate . RollAngle = 0.0 ; rtDW .
a1y4rhv5lu . OutputTemplate . RollAngleRate = 0.0 ; rtDW . c3zoqm3ek0 .
WaypointIndex = 1.0 ; rtDW . c3zoqm3ek0 . WaypointsInternal [ 0 ] *= 0.0 ;
rtDW . c3zoqm3ek0 . WaypointsInternal [ 1 ] *= 0.0 ; rtDW . c3zoqm3ek0 .
WaypointsInternal [ 2 ] *= 0.0 ; pvjunuhwfs ( & rtDW . eqsas3l3r2 ) ; } void
MdlStart ( void ) { int32_T i ; { bool externalInputIsInDatasetFormat = false
; void * pISigstreamManager = rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
blockPath = sdiGetLabelFromChars ( "UAV_Test/Bus Creator" ) ; sdiLabelU
blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiHierarchyDefinition
hTopBusHier ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T
sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions =
sigDimsArray ; hTopBusHier = sdiCreateBusHierDefinition ( ( NULL ) , "" , &
sigDims , sizeof ( FixedWingControlBus ) ) ; { sdiAsyncRepoDataTypeHandle hDT
= sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiLabelU units = sdiGetLabelFromChars ( "" ) ;
sdiDims childSigDims ; int_T childSigDimsArray [ 2 ] = { 1 , 1 } ;
childSigDims . nDims = 2 ; childSigDims . dimensions = childSigDimsArray ;
sdiAddBusHierLeaf ( hTopBusHier , ".Height" , units , 0 , hDT , sigComplexity
, & childSigDims , stCont ) ; sdiFreeLabel ( units ) ; } } {
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ; sdiLabelU units =
sdiGetLabelFromChars ( "" ) ; sdiDims childSigDims ; int_T childSigDimsArray
[ 2 ] = { 1 , 1 } ; childSigDims . nDims = 2 ; childSigDims . dimensions =
childSigDimsArray ; sdiAddBusHierLeaf ( hTopBusHier , "AirSpeed" , units , 8
, hDT , sigComplexity , & childSigDims , stCont ) ; sdiFreeLabel ( units ) ;
} } { sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ; sdiLabelU units =
sdiGetLabelFromChars ( "" ) ; sdiDims childSigDims ; int_T childSigDimsArray
[ 2 ] = { 1 , 1 } ; childSigDims . nDims = 2 ; childSigDims . dimensions =
childSigDimsArray ; sdiAddBusHierLeaf ( hTopBusHier , "RollAngle" , units ,
16 , hDT , sigComplexity , & childSigDims , stCont ) ; sdiFreeLabel ( units )
; } } srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = (
sdiFullBlkPathU ) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ;
srcInfo . subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo .
signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . ogvugh2h0k .
AQHandles = sdiCreateAsyncQueueForNVBus ( & hTopBusHier , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"7471cb9a-6c35-47a3-8ec4-8cd5541e9163" , 24 , & sigDims , stCont , 1 , 0 , ""
, "" , "" ) ; if ( rtDW . ogvugh2h0k . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . ogvugh2h0k . AQHandles , "0.01" , 0.01
, ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ogvugh2h0k . AQHandles
, 0.0 ) ; sdiSetRunStartTime ( rtDW . ogvugh2h0k . AQHandles , ssGetTaskTime
( rtS , 1 ) ) ; } sdiFreeLabel ( sigName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "Rotation" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "Rotation" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"UAV_Test/Coordinate Transformation Conversion" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "Rotation" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 2 ] = { 4 , 1 } ; sigDims . nDims = 2 ; sigDims . dimensions = sigDimsArray
; srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = (
sdiFullBlkPathU ) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ;
srcInfo . subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo .
signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . j1zd3xo5ku .
AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo .
mmi . InstanceMap . fullPath , "55915cbd-a0b8-4857-b219-4b9725ccedfb" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . j1zd3xo5ku . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . j1zd3xo5ku . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . j1zd3xo5ku . AQHandles , "0.01" , 0.01
, ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . j1zd3xo5ku . AQHandles
, 0.0 ) ; sdiSetRunStartTime ( rtDW . j1zd3xo5ku . AQHandles , ssGetTaskTime
( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . j1zd3xo5ku .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . j1zd3xo5ku .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "Translation" ) ;
sdiLabelU origSigName = sdiGetLabelFromChars ( "Translation" ) ; sdiLabelU
propName = sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "UAV_Test/Mux" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "Translation"
) ; sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 3 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . hmlotlh5bm . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "ff4f0f69-1d3d-436c-a219-1fde64e033e4" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . hmlotlh5bm . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . hmlotlh5bm . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . hmlotlh5bm . AQHandles , "0.01" , 0.01
, ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . hmlotlh5bm . AQHandles
, 0.0 ) ; sdiSetRunStartTime ( rtDW . hmlotlh5bm . AQHandles , ssGetTaskTime
( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . hmlotlh5bm .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . hmlotlh5bm .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"UAV_Test/UAV Waypoint Follower" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_UINT8 ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
2 ] = { 1 , 1 } ; sigDims . nDims = 2 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 3 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . lgovxjzz5e . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "4795e683-fba1-4016-a518-d8f65cc16bec" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . lgovxjzz5e . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . lgovxjzz5e . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . lgovxjzz5e . AQHandles , "0.01" , 0.01
, ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . lgovxjzz5e . AQHandles
, 0.0 ) ; sdiSetRunStartTime ( rtDW . lgovxjzz5e . AQHandles , ssGetTaskTime
( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . lgovxjzz5e .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . lgovxjzz5e .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "<East>" ) ;
sdiLabelU origSigName = sdiGetLabelFromChars ( "<East>" ) ; sdiLabelU
propName = sdiGetLabelFromChars ( "<East>" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "UAV_Test/To Workspace1" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "<East>" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 2 ] = { 1 , 1 } ; sigDims . nDims = 2 ; sigDims . dimensions = sigDimsArray
; srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = (
sdiFullBlkPathU ) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ;
srcInfo . subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo .
signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . dkoje3nlmk .
AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo .
mmi . InstanceMap . fullPath , "d9ecee64-339f-4750-9447-9515ebd8fd57" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. dkoje3nlmk . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . dkoje3nlmk
. AQHandles , "0.01" , 0.01 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate (
rtDW . dkoje3nlmk . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW .
dkoje3nlmk . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . dkoje3nlmk . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . dkoje3nlmk . AQHandles ,
loggedName , origSigName , propName ) ; sdiAsyncRepoSetBlockPathDomain ( rtDW
. dkoje3nlmk . AQHandles ) ; sdiSetSignalIsFrameBased ( rtDW . dkoje3nlmk .
AQHandles , true ) ; sdiCompleteAsyncioQueueCreation ( rtDW . dkoje3nlmk .
AQHandles , hDT , & srcInfo ) ; } sdiFreeLabel ( sigName ) ; sdiFreeLabel (
loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel ( propName ) ;
sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ; sdiFreeLabel (
subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { { sdiLabelU varName =
sdiGetLabelFromChars ( "East" ) ; sdiRegisterWksVariable ( rtDW . dkoje3nlmk
. AQHandles , varName , "array2D" ) ; sdiFreeLabel ( varName ) ; } } } } } {
{ { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "<North>" ) ;
sdiLabelU origSigName = sdiGetLabelFromChars ( "<North>" ) ; sdiLabelU
propName = sdiGetLabelFromChars ( "<North>" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "UAV_Test/To Workspace2" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "<North>" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 2 ] = { 1 , 1 } ; sigDims . nDims = 2 ; sigDims . dimensions = sigDimsArray
; srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = (
sdiFullBlkPathU ) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ;
srcInfo . subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo .
signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . hj3h3tskaf .
AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo .
mmi . InstanceMap . fullPath , "670784e0-0092-4959-8f99-321f130e6c27" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. hj3h3tskaf . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . hj3h3tskaf
. AQHandles , "0.01" , 0.01 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate (
rtDW . hj3h3tskaf . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW .
hj3h3tskaf . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . hj3h3tskaf . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . hj3h3tskaf . AQHandles ,
loggedName , origSigName , propName ) ; sdiAsyncRepoSetBlockPathDomain ( rtDW
. hj3h3tskaf . AQHandles ) ; sdiSetSignalIsFrameBased ( rtDW . hj3h3tskaf .
AQHandles , true ) ; sdiCompleteAsyncioQueueCreation ( rtDW . hj3h3tskaf .
AQHandles , hDT , & srcInfo ) ; } sdiFreeLabel ( sigName ) ; sdiFreeLabel (
loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel ( propName ) ;
sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ; sdiFreeLabel (
subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { { sdiLabelU varName =
sdiGetLabelFromChars ( "North" ) ; sdiRegisterWksVariable ( rtDW . hj3h3tskaf
. AQHandles , varName , "array2D" ) ; sdiFreeLabel ( varName ) ; } } } } } {
{ { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "<Height>" ) ;
sdiLabelU origSigName = sdiGetLabelFromChars ( "<Height>" ) ; sdiLabelU
propName = sdiGetLabelFromChars ( "<Height>" ) ; sdiLabelU blockPath =
sdiGetLabelFromChars ( "UAV_Test/To Workspace3" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "<Height>" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 2 ] = { 1 , 1 } ; sigDims . nDims = 2 ; sigDims . dimensions = sigDimsArray
; srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = (
sdiFullBlkPathU ) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ;
srcInfo . subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo .
signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . cn4cqyqs1h .
AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo .
mmi . InstanceMap . fullPath , "15abc8d4-e548-4156-9d44-2f43ca34a878" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ; if ( rtDW
. cn4cqyqs1h . AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . cn4cqyqs1h
. AQHandles , "0.01" , 0.01 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate (
rtDW . cn4cqyqs1h . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW .
cn4cqyqs1h . AQHandles , ssGetTaskTime ( rtS , 1 ) ) ;
sdiAsyncRepoSetSignalExportSettings ( rtDW . cn4cqyqs1h . AQHandles , 1 , 0 )
; sdiAsyncRepoSetSignalExportName ( rtDW . cn4cqyqs1h . AQHandles ,
loggedName , origSigName , propName ) ; sdiAsyncRepoSetBlockPathDomain ( rtDW
. cn4cqyqs1h . AQHandles ) ; sdiSetSignalIsFrameBased ( rtDW . cn4cqyqs1h .
AQHandles , true ) ; sdiCompleteAsyncioQueueCreation ( rtDW . cn4cqyqs1h .
AQHandles , hDT , & srcInfo ) ; } sdiFreeLabel ( sigName ) ; sdiFreeLabel (
loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel ( propName ) ;
sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ; sdiFreeLabel (
subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { { sdiLabelU varName =
sdiGetLabelFromChars ( "Height" ) ; sdiRegisterWksVariable ( rtDW .
cn4cqyqs1h . AQHandles , varName , "array2D" ) ; sdiFreeLabel ( varName ) ; }
} } } } rtDW . afbl01xbna = true ; rtDW . a1y4rhv5lu . isInitialized = 1 ;
rtDW . a1y4rhv5lu . OutputTemplate . North = 0.0 ; rtDW . a1y4rhv5lu .
OutputTemplate . East = 0.0 ; rtDW . a1y4rhv5lu . OutputTemplate . Height =
0.0 ; rtDW . a1y4rhv5lu . OutputTemplate . AirSpeed = 0.0 ; rtDW . a1y4rhv5lu
. OutputTemplate . HeadingAngle = 0.0 ; rtDW . a1y4rhv5lu . OutputTemplate .
FlightPathAngle = 0.0 ; rtDW . a1y4rhv5lu . OutputTemplate . RollAngle = 0.0
; rtDW . a1y4rhv5lu . OutputTemplate . RollAngleRate = 0.0 ; rtDW .
c3zoqm3ek0 . LastWaypointFlag = false ; rtDW . c3zoqm3ek0 . StartFlag = true
; rtDW . c3zoqm3ek0 . LookaheadFactor = 1.01 ; rtDW . d4iqeyqmip = true ;
rtDW . c3zoqm3ek0 . isInitialized = 1 ; for ( i = 0 ; i < 8 ; i ++ ) { rtDW .
c3zoqm3ek0 . inputVarSize [ 0 ] . f1 [ i ] = 1U ; } rtDW . c3zoqm3ek0 .
inputVarSize [ 1 ] . f1 [ 0 ] = 1U ; rtDW . c3zoqm3ek0 . inputVarSize [ 1 ] .
f1 [ 1 ] = 3U ; for ( i = 0 ; i < 6 ; i ++ ) { rtDW . c3zoqm3ek0 .
inputVarSize [ 1 ] . f1 [ i + 2 ] = 1U ; } for ( i = 0 ; i < 8 ; i ++ ) {
rtDW . c3zoqm3ek0 . inputVarSize [ 2 ] . f1 [ i ] = 1U ; } rtDW . c3zoqm3ek0
. WaypointsInternal [ 0 ] = 0.0 ; rtDW . c3zoqm3ek0 . WaypointsInternal [ 1 ]
= 0.0 ; rtDW . c3zoqm3ek0 . WaypointsInternal [ 2 ] = 0.0 ; rtDW . c3zoqm3ek0
. NumWaypoints = 0.0 ; rtDW . da34mwshey = true ; rtDW . m2byiavbd3 .
isInitialized = 1 ; rtDW . diciq4bwp5 = true ; rtDW . hdlxlx4cyh .
isInitialized = 1 ; rtDW . jathlujjus = true ; rtDW . eqsas3l3r2 .
isInitialized = 1 ; pvjunuhwfs ( & rtDW . eqsas3l3r2 ) ; MdlInitialize ( ) ;
} void MdlOutputs ( int_T tid ) { FixedWingControlBus bww54olp5t ; real_T
appendedWaypoints [ 6 ] ; real_T fmvbxriq25_p [ 3 ] ; real_T r [ 3 ] ; real_T
absx ; real_T b ; real_T c_idx_0 ; real_T c_idx_1 ; real_T c_idx_2 ; real_T
fmvbxriq25_idx_2 ; real_T lambda ; int32_T b_exponent ; int32_T b_exponent_p
; int32_T b_k ; int32_T e ; int8_T inSize [ 8 ] ; boolean_T exitg1 ;
boolean_T guard1 = false ; boolean_T pos ; boolean_T rEQ0 ; rtB . mlb0e0sr0w
. North = rtX . dxenv44p1n [ 0 ] ; rtB . mlb0e0sr0w . East = rtX . dxenv44p1n
[ 1 ] ; rtB . mlb0e0sr0w . Height = rtX . dxenv44p1n [ 2 ] ; rtB . mlb0e0sr0w
. AirSpeed = rtX . dxenv44p1n [ 3 ] ; rtB . mlb0e0sr0w . HeadingAngle = rtX .
dxenv44p1n [ 4 ] ; rtB . mlb0e0sr0w . FlightPathAngle = rtX . dxenv44p1n [ 5
] ; rtB . mlb0e0sr0w . RollAngle = rtX . dxenv44p1n [ 6 ] ; rtB . mlb0e0sr0w
. RollAngleRate = rtX . dxenv44p1n [ 7 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 )
) { rtB . jaclmxlu53 = rtB . mlb0e0sr0w ; fmvbxriq25_idx_2 = rtP . Gain1_Gain
* rtB . jaclmxlu53 . Height ; inSize [ 0 ] = 1 ; inSize [ 1 ] = 3 ; for ( b_k
= 0 ; b_k < 6 ; b_k ++ ) { inSize [ b_k + 2 ] = 1 ; } b_k = 0 ; exitg1 =
false ; while ( ( ! exitg1 ) && ( b_k < 8 ) ) { if ( rtDW . c3zoqm3ek0 .
inputVarSize [ 1 ] . f1 [ b_k ] != ( uint32_T ) inSize [ b_k ] ) { for ( b_k
= 0 ; b_k < 8 ; b_k ++ ) { rtDW . c3zoqm3ek0 . inputVarSize [ 1 ] . f1 [ b_k
] = ( uint32_T ) inSize [ b_k ] ; } exitg1 = true ; } else { b_k ++ ; } }
lambda = rtP . LookaheadDistance_Value ; rtDW . c3zoqm3ek0 .
LookaheadDistFlag = 0U ; if ( rtP . LookaheadDistance_Value < 0.1 ) { lambda
= 0.1 ; rtDW . c3zoqm3ek0 . LookaheadDistFlag = 1U ; } rtDW . c3zoqm3ek0 .
InitialPose [ 0 ] = 0.0 ; rtDW . c3zoqm3ek0 . InitialPose [ 1 ] = 0.0 ; rtDW
. c3zoqm3ek0 . InitialPose [ 2 ] = 0.0 ; rtDW . c3zoqm3ek0 . InitialPose [ 3
] = 0.0 ; rtDW . c3zoqm3ek0 . NumWaypoints = 1.0 ; guard1 = false ; if ( rtDW
. c3zoqm3ek0 . NumWaypoints != 1.0 ) { guard1 = true ; } else { if ( rtDW .
c3zoqm3ek0 . NumWaypoints < 1.0 ) { b_k = 0 ; e = 0 ; } else { b_k = 1 ; e =
1 ; } pos = false ; rEQ0 = false ; if ( b_k == e ) { rEQ0 = true ; } if (
rEQ0 && ( b_k != 0 ) && ( e != 0 ) ) { b_k = 0 ; exitg1 = false ; while ( ( !
exitg1 ) && ( b_k <= 2 ) ) { if ( ! ( rtDW . c3zoqm3ek0 . WaypointsInternal [
b_k ] == rtP . Waypoints_Value [ b_k ] ) ) { rEQ0 = false ; exitg1 = true ; }
else { b_k ++ ; } } } if ( rEQ0 ) { pos = true ; } if ( ! pos ) { guard1 =
true ; } } if ( guard1 ) { rtDW . c3zoqm3ek0 . WaypointsInternal [ 0 ] = rtP
. Waypoints_Value [ 0 ] ; rtDW . c3zoqm3ek0 . WaypointsInternal [ 1 ] = rtP .
Waypoints_Value [ 1 ] ; rtDW . c3zoqm3ek0 . WaypointsInternal [ 2 ] = rtP .
Waypoints_Value [ 2 ] ; rtDW . c3zoqm3ek0 . WaypointIndex = 1.0 ; } rtDW .
c3zoqm3ek0 . LookaheadDistance = lambda ; if ( rtDW . c3zoqm3ek0 . StartFlag
) { rtDW . c3zoqm3ek0 . InitialPose [ 0 ] = rtB . jaclmxlu53 . North ; rtDW .
c3zoqm3ek0 . InitialPose [ 1 ] = rtB . jaclmxlu53 . East ; rtDW . c3zoqm3ek0
. InitialPose [ 2 ] = fmvbxriq25_idx_2 ; rtDW . c3zoqm3ek0 . InitialPose [ 3
] = rtB . jaclmxlu53 . HeadingAngle ; } fmvbxriq25_p [ 0 ] = rtP .
Waypoints_Value [ 0 ] - rtB . jaclmxlu53 . North ; fmvbxriq25_p [ 1 ] = rtP .
Waypoints_Value [ 1 ] - rtB . jaclmxlu53 . East ; fmvbxriq25_p [ 2 ] = rtP .
Waypoints_Value [ 2 ] - fmvbxriq25_idx_2 ; if ( eyukbmfsyx ( fmvbxriq25_p ) <
1.4901161193847656E-8 ) { r [ 2 ] = lambda * 0.0 + fmvbxriq25_idx_2 ; absx =
rtB . jaclmxlu53 . HeadingAngle ; rtDW . c3zoqm3ek0 . StartFlag = false ; }
else { rtDW . c3zoqm3ek0 . StartFlag = false ; appendedWaypoints [ 0 ] = rtDW
. c3zoqm3ek0 . InitialPose [ 0 ] ; appendedWaypoints [ 1 ] = rtP .
Waypoints_Value [ 0 ] ; appendedWaypoints [ 2 ] = rtDW . c3zoqm3ek0 .
InitialPose [ 1 ] ; appendedWaypoints [ 3 ] = rtP . Waypoints_Value [ 1 ] ;
appendedWaypoints [ 4 ] = rtDW . c3zoqm3ek0 . InitialPose [ 2 ] ;
appendedWaypoints [ 5 ] = rtP . Waypoints_Value [ 2 ] ; rtDW . c3zoqm3ek0 .
NumWaypoints = 2.0 ; pos = false ; if ( rtDW . c3zoqm3ek0 . WaypointIndex ==
rtDW . c3zoqm3ek0 . NumWaypoints ) { pos = true ; } if ( pos ) { rtDW .
c3zoqm3ek0 . LastWaypointFlag = true ; rtDW . c3zoqm3ek0 . WaypointIndex -- ;
} fmvbxriq25_p [ 0 ] = rtB . jaclmxlu53 . North - appendedWaypoints [ (
int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) - 1 ] ; fmvbxriq25_p [
1 ] = rtB . jaclmxlu53 . East - appendedWaypoints [ ( int32_T ) ( rtDW .
c3zoqm3ek0 . WaypointIndex + 1.0 ) + 1 ] ; fmvbxriq25_p [ 2 ] =
fmvbxriq25_idx_2 - appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 .
WaypointIndex + 1.0 ) + 3 ] ; guard1 = false ; if ( eyukbmfsyx ( fmvbxriq25_p
) <= 100.0 ) { guard1 = true ; } else { r [ 0 ] = appendedWaypoints [ (
int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) - 1 ] -
appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 . WaypointIndex - 1 ] ; r [
1 ] = appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex +
1.0 ) + 1 ] - appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 .
WaypointIndex + 1 ] ; r [ 2 ] = appendedWaypoints [ ( int32_T ) ( rtDW .
c3zoqm3ek0 . WaypointIndex + 1.0 ) + 3 ] - appendedWaypoints [ ( int32_T )
rtDW . c3zoqm3ek0 . WaypointIndex + 3 ] ; c_idx_0 = eyukbmfsyx ( r ) ;
fmvbxriq25_p [ 0 ] = rtB . jaclmxlu53 . North - appendedWaypoints [ ( int32_T
) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) - 1 ] ; fmvbxriq25_p [ 1 ] =
rtB . jaclmxlu53 . East - appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0
. WaypointIndex + 1.0 ) + 1 ] ; fmvbxriq25_p [ 2 ] = fmvbxriq25_idx_2 -
appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) +
3 ] ; absx = eyukbmfsyx ( fmvbxriq25_p ) ; if ( muDoubleScalarSign ( ( (
appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) -
1 ] - appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 . WaypointIndex - 1 ]
) / c_idx_0 * ( ( rtB . jaclmxlu53 . North - appendedWaypoints [ ( int32_T )
( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) - 1 ] ) / absx ) + (
appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) +
1 ] - appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 . WaypointIndex + 1 ]
) / c_idx_0 * ( ( rtB . jaclmxlu53 . East - appendedWaypoints [ ( int32_T ) (
rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) + 1 ] ) / absx ) ) + (
appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) +
3 ] - appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 . WaypointIndex + 3 ]
) / c_idx_0 * ( ( fmvbxriq25_idx_2 - appendedWaypoints [ ( int32_T ) ( rtDW .
c3zoqm3ek0 . WaypointIndex + 1.0 ) + 3 ] ) / absx ) ) >= 0.0 ) { guard1 =
true ; } else { c_idx_0 = appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 .
WaypointIndex - 1 ] ; r [ 0 ] = appendedWaypoints [ ( int32_T ) ( rtDW .
c3zoqm3ek0 . WaypointIndex + 1.0 ) - 1 ] ; c_idx_1 = appendedWaypoints [ (
int32_T ) rtDW . c3zoqm3ek0 . WaypointIndex + 1 ] ; r [ 1 ] =
appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) +
1 ] ; c_idx_2 = appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 .
WaypointIndex + 3 ] ; r [ 2 ] = appendedWaypoints [ ( int32_T ) ( rtDW .
c3zoqm3ek0 . WaypointIndex + 1.0 ) + 3 ] ; } } if ( guard1 ) { rtDW .
c3zoqm3ek0 . WaypointIndex ++ ; pos = false ; if ( rtDW . c3zoqm3ek0 .
WaypointIndex == rtDW . c3zoqm3ek0 . NumWaypoints ) { pos = true ; } if ( pos
) { rtDW . c3zoqm3ek0 . LastWaypointFlag = true ; rtDW . c3zoqm3ek0 .
WaypointIndex -- ; } c_idx_0 = appendedWaypoints [ ( int32_T ) rtDW .
c3zoqm3ek0 . WaypointIndex - 1 ] ; r [ 0 ] = appendedWaypoints [ ( int32_T )
( rtDW . c3zoqm3ek0 . WaypointIndex + 1.0 ) - 1 ] ; c_idx_1 =
appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 . WaypointIndex + 1 ] ; r [
1 ] = appendedWaypoints [ ( int32_T ) ( rtDW . c3zoqm3ek0 . WaypointIndex +
1.0 ) + 1 ] ; c_idx_2 = appendedWaypoints [ ( int32_T ) rtDW . c3zoqm3ek0 .
WaypointIndex + 3 ] ; r [ 2 ] = appendedWaypoints [ ( int32_T ) ( rtDW .
c3zoqm3ek0 . WaypointIndex + 1.0 ) + 3 ] ; } lambda = ( ( ( rtB . jaclmxlu53
. North - c_idx_0 ) * ( r [ 0 ] - c_idx_0 ) + ( rtB . jaclmxlu53 . East -
c_idx_1 ) * ( r [ 1 ] - c_idx_1 ) ) + ( fmvbxriq25_idx_2 - c_idx_2 ) * ( r [
2 ] - c_idx_2 ) ) / ( ( ( r [ 0 ] - c_idx_0 ) * ( r [ 0 ] - c_idx_0 ) + ( r [
1 ] - c_idx_1 ) * ( r [ 1 ] - c_idx_1 ) ) + ( r [ 2 ] - c_idx_2 ) * ( r [ 2 ]
- c_idx_2 ) ) ; if ( lambda < 0.0 ) { fmvbxriq25_p [ 0 ] = rtB . jaclmxlu53 .
North - c_idx_0 ; fmvbxriq25_p [ 1 ] = rtB . jaclmxlu53 . East - c_idx_1 ;
fmvbxriq25_p [ 2 ] = fmvbxriq25_idx_2 - c_idx_2 ; lambda = eyukbmfsyx (
fmvbxriq25_p ) ; } else if ( lambda > 1.0 ) { fmvbxriq25_p [ 0 ] = rtB .
jaclmxlu53 . North - r [ 0 ] ; fmvbxriq25_p [ 1 ] = rtB . jaclmxlu53 . East -
r [ 1 ] ; fmvbxriq25_p [ 2 ] = fmvbxriq25_idx_2 - r [ 2 ] ; lambda =
eyukbmfsyx ( fmvbxriq25_p ) ; } else { fmvbxriq25_p [ 0 ] = rtB . jaclmxlu53
. North - ( ( r [ 0 ] - c_idx_0 ) * lambda + c_idx_0 ) ; fmvbxriq25_p [ 1 ] =
rtB . jaclmxlu53 . East - ( ( r [ 1 ] - c_idx_1 ) * lambda + c_idx_1 ) ;
fmvbxriq25_p [ 2 ] = fmvbxriq25_idx_2 - ( ( r [ 2 ] - c_idx_2 ) * lambda +
c_idx_2 ) ; lambda = eyukbmfsyx ( fmvbxriq25_p ) ; } if ( rtDW . c3zoqm3ek0 .
LastWaypointFlag ) { lambda = ( ( ( rtB . jaclmxlu53 . North - c_idx_0 ) * (
r [ 0 ] - c_idx_0 ) + ( rtB . jaclmxlu53 . East - c_idx_1 ) * ( r [ 1 ] -
c_idx_1 ) ) + ( fmvbxriq25_idx_2 - c_idx_2 ) * ( r [ 2 ] - c_idx_2 ) ) / ( (
( r [ 0 ] - c_idx_0 ) * ( r [ 0 ] - c_idx_0 ) + ( r [ 1 ] - c_idx_1 ) * ( r [
1 ] - c_idx_1 ) ) + ( r [ 2 ] - c_idx_2 ) * ( r [ 2 ] - c_idx_2 ) ) ;
fmvbxriq25_p [ 0 ] = rtB . jaclmxlu53 . North - ( ( r [ 0 ] - c_idx_0 ) *
lambda + c_idx_0 ) ; fmvbxriq25_p [ 1 ] = rtB . jaclmxlu53 . East - ( ( r [ 1
] - c_idx_1 ) * lambda + c_idx_1 ) ; fmvbxriq25_p [ 2 ] = fmvbxriq25_idx_2 -
( ( r [ 2 ] - c_idx_2 ) * lambda + c_idx_2 ) ; lambda = eyukbmfsyx (
fmvbxriq25_p ) ; } absx = muDoubleScalarAbs ( lambda ) ; if (
muDoubleScalarIsInf ( absx ) || muDoubleScalarIsNaN ( absx ) ) { b = ( rtNaN
) ; } else if ( absx < 4.4501477170144028E-308 ) { b = 4.94065645841247E-324
; } else { frexp ( absx , & b_exponent ) ; b = ldexp ( 1.0 , b_exponent - 53
) ; } absx = muDoubleScalarAbs ( lambda ) ; if ( muDoubleScalarIsInf ( absx )
|| muDoubleScalarIsNaN ( absx ) ) { absx = ( rtNaN ) ; } else if ( absx <
4.4501477170144028E-308 ) { absx = 4.94065645841247E-324 ; } else { frexp (
absx , & b_exponent_p ) ; absx = ldexp ( 1.0 , b_exponent_p - 53 ) ; } if (
rtDW . c3zoqm3ek0 . LookaheadDistance <= muDoubleScalarMax (
muDoubleScalarSqrt ( b ) , 5.0 * absx ) + lambda ) { rtDW . c3zoqm3ek0 .
LookaheadDistance = rtDW . c3zoqm3ek0 . LookaheadFactor * lambda ; } lambda =
( ( r [ 0 ] - c_idx_0 ) * ( r [ 0 ] - c_idx_0 ) + ( r [ 1 ] - c_idx_1 ) * ( r
[ 1 ] - c_idx_1 ) ) + ( r [ 2 ] - c_idx_2 ) * ( r [ 2 ] - c_idx_2 ) ; b = ( (
( r [ 0 ] - c_idx_0 ) * ( c_idx_0 - rtB . jaclmxlu53 . North ) + ( r [ 1 ] -
c_idx_1 ) * ( c_idx_1 - rtB . jaclmxlu53 . East ) ) + ( r [ 2 ] - c_idx_2 ) *
( c_idx_2 - fmvbxriq25_idx_2 ) ) * 2.0 ; absx = b * b - ( ( ( ( c_idx_0 - rtB
. jaclmxlu53 . North ) * ( c_idx_0 - rtB . jaclmxlu53 . North ) + ( c_idx_1 -
rtB . jaclmxlu53 . East ) * ( c_idx_1 - rtB . jaclmxlu53 . East ) ) + (
c_idx_2 - fmvbxriq25_idx_2 ) * ( c_idx_2 - fmvbxriq25_idx_2 ) ) - rtDW .
c3zoqm3ek0 . LookaheadDistance * rtDW . c3zoqm3ek0 . LookaheadDistance ) * (
4.0 * lambda ) ; lambda = muDoubleScalarMax ( ( - b + muDoubleScalarSqrt (
absx ) ) / 2.0 / lambda , ( - b - muDoubleScalarSqrt ( absx ) ) / 2.0 /
lambda ) ; r [ 0 ] = ( 1.0 - lambda ) * c_idx_0 + lambda * r [ 0 ] ; r [ 1 ]
= ( 1.0 - lambda ) * c_idx_1 + lambda * r [ 1 ] ; r [ 2 ] = ( 1.0 - lambda )
* c_idx_2 + lambda * r [ 2 ] ; absx = muDoubleScalarAtan2 ( r [ 1 ] - rtB .
jaclmxlu53 . East , r [ 0 ] - rtB . jaclmxlu53 . North ) ; rtDW . c3zoqm3ek0
. LastWaypointFlag = false ; } rtB . fphsuwgig0 = rtDW . c3zoqm3ek0 .
LookaheadDistFlag ; rtB . i2ayzuafga . WindNorth = rtP . Constant1_Value ;
rtB . i2ayzuafga . WindEast = rtP . Constant2_Value_dde35bhip2 ; rtB .
i2ayzuafga . WindDown = rtP . Constant3_Value ; rtB . i2ayzuafga . Gravity =
rtP . Constant_Value ; rtDW . a5dgdf4x33 = klxv1hydll ; lambda = 1.0 / rtB .
jaclmxlu53 . AirSpeed ; c_idx_0 = ( muDoubleScalarCos ( rtB . jaclmxlu53 .
HeadingAngle ) * muDoubleScalarCos ( rtB . jaclmxlu53 . FlightPathAngle ) *
rtB . i2ayzuafga . WindNorth + muDoubleScalarSin ( rtB . jaclmxlu53 .
HeadingAngle ) * muDoubleScalarCos ( rtB . jaclmxlu53 . FlightPathAngle ) *
rtB . i2ayzuafga . WindEast ) + - muDoubleScalarSin ( rtB . jaclmxlu53 .
FlightPathAngle ) * rtB . i2ayzuafga . WindDown ; absx -= rtB . jaclmxlu53 .
HeadingAngle ; if ( muDoubleScalarAbs ( absx ) > 3.1415926535897931 ) { if (
muDoubleScalarIsNaN ( absx + 3.1415926535897931 ) || muDoubleScalarIsInf (
absx + 3.1415926535897931 ) ) { fmvbxriq25_idx_2 = ( rtNaN ) ; } else if (
absx + 3.1415926535897931 == 0.0 ) { fmvbxriq25_idx_2 = 0.0 ; } else {
fmvbxriq25_idx_2 = muDoubleScalarRem ( absx + 3.1415926535897931 ,
6.2831853071795862 ) ; rEQ0 = ( fmvbxriq25_idx_2 == 0.0 ) ; if ( ! rEQ0 ) {
c_idx_1 = muDoubleScalarAbs ( ( absx + 3.1415926535897931 ) /
6.2831853071795862 ) ; rEQ0 = ! ( muDoubleScalarAbs ( c_idx_1 -
muDoubleScalarFloor ( c_idx_1 + 0.5 ) ) > 2.2204460492503131E-16 * c_idx_1 )
; } if ( rEQ0 ) { fmvbxriq25_idx_2 = 0.0 ; } else if ( absx +
3.1415926535897931 < 0.0 ) { fmvbxriq25_idx_2 += 6.2831853071795862 ; } } if
( ( fmvbxriq25_idx_2 == 0.0 ) && ( absx + 3.1415926535897931 > 0.0 ) ) {
fmvbxriq25_idx_2 = 6.2831853071795862 ; } absx = fmvbxriq25_idx_2 -
3.1415926535897931 ; } bww54olp5t . Height = rtP . Gain2_Gain * r [ 2 ] ;
bww54olp5t . AirSpeed = rtP . Constant2_Value ; absx = muDoubleScalarAtan2 (
( muDoubleScalarSqrt ( c_idx_0 * c_idx_0 - ( ( ( rtB . i2ayzuafga . WindNorth
* rtB . i2ayzuafga . WindNorth + rtB . i2ayzuafga . WindEast * rtB .
i2ayzuafga . WindEast ) + rtB . i2ayzuafga . WindDown * rtB . i2ayzuafga .
WindDown ) - rtB . jaclmxlu53 . AirSpeed * rtB . jaclmxlu53 . AirSpeed ) ) -
c_idx_0 ) * ( rtP . HeadingConrol_PHeadingAngle * absx ) , muDoubleScalarCos
( rtB . jaclmxlu53 . HeadingAngle - ( rtB . jaclmxlu53 . HeadingAngle -
muDoubleScalarAsin ( lambda * rtB . i2ayzuafga . WindNorth * -
muDoubleScalarSin ( rtB . jaclmxlu53 . HeadingAngle ) + lambda * rtB .
i2ayzuafga . WindEast * muDoubleScalarCos ( rtB . jaclmxlu53 . HeadingAngle )
) ) ) * rtB . i2ayzuafga . Gravity ) ; if ( absx > rtP . Saturation2_UpperSat
) { bww54olp5t . RollAngle = rtP . Saturation2_UpperSat ; } else if ( absx <
rtP . Saturation2_LowerSat ) { bww54olp5t . RollAngle = rtP .
Saturation2_LowerSat ; } else { bww54olp5t . RollAngle = absx ; } { if ( rtDW
. ogvugh2h0k . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW
. ogvugh2h0k . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) &
bww54olp5t + 0 ) ; } } } r [ 0 ] = rtB . mlb0e0sr0w . HeadingAngle ; r [ 1 ]
= rtB . mlb0e0sr0w . FlightPathAngle ; r [ 2 ] = rtB . mlb0e0sr0w . RollAngle
; c_idx_0 = muDoubleScalarCos ( r [ 0 ] / 2.0 ) ; r [ 0 ] /= 2.0 ; c_idx_1 =
muDoubleScalarCos ( r [ 1 ] / 2.0 ) ; r [ 1 ] /= 2.0 ; c_idx_2 =
muDoubleScalarCos ( r [ 2 ] / 2.0 ) ; r [ 2 ] /= 2.0 ; r [ 0 ] =
muDoubleScalarSin ( r [ 0 ] ) ; r [ 1 ] = muDoubleScalarSin ( r [ 1 ] ) ; r [
2 ] = muDoubleScalarSin ( r [ 2 ] ) ; rtB . if42dzhbz4 [ 0 ] = c_idx_0 *
c_idx_1 * c_idx_2 + r [ 0 ] * r [ 1 ] * r [ 2 ] ; rtB . if42dzhbz4 [ 1 ] =
c_idx_0 * c_idx_1 * r [ 2 ] - r [ 0 ] * r [ 1 ] * c_idx_2 ; rtB . if42dzhbz4
[ 2 ] = c_idx_0 * r [ 1 ] * c_idx_2 + r [ 0 ] * c_idx_1 * r [ 2 ] ; rtB .
if42dzhbz4 [ 3 ] = r [ 0 ] * c_idx_1 * c_idx_2 - c_idx_0 * r [ 1 ] * r [ 2 ]
; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW . j1zd3xo5ku . AQHandles
&& ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . j1zd3xo5ku . AQHandles
, ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . if42dzhbz4 [ 0 ] + 0 ) ; } }
} rtB . nq0zt43ydn = rtB . mlb0e0sr0w . North ; rtB . c5mxrwdcg5 = rtB .
mlb0e0sr0w . East ; rtB . acfna5rqkg = rtB . mlb0e0sr0w . Height ; rtB .
dpgfngmojw = rtP . Gain_Gain * rtB . acfna5rqkg ; if ( ssIsSampleHit ( rtS ,
1 , 0 ) ) { r [ 0 ] = rtB . nq0zt43ydn ; r [ 1 ] = rtB . c5mxrwdcg5 ; r [ 2 ]
= rtB . dpgfngmojw ; { if ( rtDW . hmlotlh5bm . AQHandles && ssGetLogOutput (
rtS ) ) { sdiWriteSignal ( rtDW . hmlotlh5bm . AQHandles , ssGetTaskTime (
rtS , 1 ) , ( char * ) & r [ 0 ] + 0 ) ; } } { if ( rtDW . lgovxjzz5e .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . lgovxjzz5e .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . fphsuwgig0 + 0 ) ;
} } { if ( rtDW . dkoje3nlmk . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . dkoje3nlmk . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . c5mxrwdcg5 + 0 ) ; } } { if ( rtDW . hj3h3tskaf .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . hj3h3tskaf .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . nq0zt43ydn + 0 ) ;
} } { if ( rtDW . cn4cqyqs1h . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . cn4cqyqs1h . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . acfna5rqkg + 0 ) ; } } if ( ssIsSampleHit ( rtS , 2 , 0 )
) { rtDW . gnviqiqrwj = bww54olp5t ; } } if ( ssIsSampleHit ( rtS , 2 , 0 ) )
{ rtB . levrkdc53u = rtDW . gnviqiqrwj ; } c_idx_0 = ( - ( muDoubleScalarCos
( rtX . dxenv44p1n [ 4 ] ) * muDoubleScalarCos ( rtX . dxenv44p1n [ 5 ] ) ) *
rtB . i2ayzuafga . WindNorth + - ( muDoubleScalarSin ( rtX . dxenv44p1n [ 4 ]
) * muDoubleScalarCos ( rtX . dxenv44p1n [ 5 ] ) ) * rtB . i2ayzuafga .
WindEast ) + muDoubleScalarSin ( rtX . dxenv44p1n [ 5 ] ) * rtB . i2ayzuafga
. WindDown ; b = muDoubleScalarSqrt ( c_idx_0 * c_idx_0 - ( ( ( rtB .
i2ayzuafga . WindNorth * rtB . i2ayzuafga . WindNorth + rtB . i2ayzuafga .
WindEast * rtB . i2ayzuafga . WindEast ) + rtB . i2ayzuafga . WindDown * rtB
. i2ayzuafga . WindDown ) - rtX . dxenv44p1n [ 3 ] * rtX . dxenv44p1n [ 3 ] )
) - c_idx_0 ; rtB . jn4qlnqquf [ 0 ] = b * muDoubleScalarCos ( rtX .
dxenv44p1n [ 4 ] ) * muDoubleScalarCos ( rtX . dxenv44p1n [ 5 ] ) ; rtB .
jn4qlnqquf [ 1 ] = b * muDoubleScalarSin ( rtX . dxenv44p1n [ 4 ] ) *
muDoubleScalarCos ( rtX . dxenv44p1n [ 5 ] ) ; rtB . jn4qlnqquf [ 2 ] = b *
muDoubleScalarSin ( rtX . dxenv44p1n [ 5 ] ) ; rtB . jn4qlnqquf [ 3 ] = ( rtB
. levrkdc53u . AirSpeed - rtX . dxenv44p1n [ 3 ] ) * rtDW . eqsas3l3r2 .
ModelImpl . Configuration . PAirSpeed ; if ( b == 0.0 ) { rtB . jn4qlnqquf [
4 ] = 0.0 ; rtB . jn4qlnqquf [ 5 ] = 0.0 ; } else { if ( rtX . dxenv44p1n [ 3
] == 0.0 ) { rtB . jn4qlnqquf [ 4 ] = 0.0 ; } else { lambda = 1.0 / (
muDoubleScalarCos ( muDoubleScalarAsin ( ( b * muDoubleScalarSin ( rtX .
dxenv44p1n [ 5 ] ) + rtB . i2ayzuafga . WindDown ) / rtX . dxenv44p1n [ 3 ] )
) * rtX . dxenv44p1n [ 3 ] ) ; rtB . jn4qlnqquf [ 4 ] = muDoubleScalarCos (
muDoubleScalarAsin ( lambda * rtB . i2ayzuafga . WindNorth * -
muDoubleScalarSin ( rtX . dxenv44p1n [ 4 ] ) + lambda * rtB . i2ayzuafga .
WindEast * muDoubleScalarCos ( rtX . dxenv44p1n [ 4 ] ) ) ) * ( rtB .
i2ayzuafga . Gravity / b * muDoubleScalarTan ( rtX . dxenv44p1n [ 6 ] ) ) ; }
rtB . jn4qlnqquf [ 5 ] = ( muDoubleScalarMax ( muDoubleScalarMin (
muDoubleScalarAsin ( muDoubleScalarMax ( muDoubleScalarMin ( ( rtB .
levrkdc53u . Height - rtX . dxenv44p1n [ 2 ] ) * rtDW . eqsas3l3r2 .
ModelImpl . Configuration . PHeight / b , 1.0 ) , - 1.0 ) ) , rtDW .
eqsas3l3r2 . ModelImpl . Configuration . FlightPathAngleLimits [ 1 ] ) , rtDW
. eqsas3l3r2 . ModelImpl . Configuration . FlightPathAngleLimits [ 0 ] ) -
rtX . dxenv44p1n [ 5 ] ) * rtDW . eqsas3l3r2 . ModelImpl . Configuration .
PFlightPathAngle ; } rtB . jn4qlnqquf [ 6 ] = rtX . dxenv44p1n [ 7 ] ; rtB .
jn4qlnqquf [ 7 ] = ( muDoubleScalarMax ( muDoubleScalarMin ( rtB . levrkdc53u
. RollAngle , 1.5707963267948966 ) , - 1.5707963267948966 ) - rtX .
dxenv44p1n [ 6 ] ) * rtDW . eqsas3l3r2 . ModelImpl . Configuration . PDRoll [
0 ] + rtDW . eqsas3l3r2 . ModelImpl . Configuration . PDRoll [ 1 ] * - rtX .
dxenv44p1n [ 7 ] ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { } UNUSED_PARAMETER
( tid ) ; } void MdlOutputsTID3 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; }
void MdlUpdate ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlUpdateTID3 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlDerivatives ( void ) { XDot * _rtXdot ; _rtXdot = ( ( XDot * ) ssGetdX (
rtS ) ) ; memcpy ( & _rtXdot -> dxenv44p1n [ 0 ] , & rtB . jn4qlnqquf [ 0 ] ,
sizeof ( real_T ) << 3U ) ; } void MdlProjection ( void ) { } void
MdlTerminate ( void ) { { if ( rtDW . ogvugh2h0k . AQHandles ) {
sdiTerminateStreaming ( & rtDW . ogvugh2h0k . AQHandles ) ; } } { if ( rtDW .
j1zd3xo5ku . AQHandles ) { sdiTerminateStreaming ( & rtDW . j1zd3xo5ku .
AQHandles ) ; } } { if ( rtDW . hmlotlh5bm . AQHandles ) {
sdiTerminateStreaming ( & rtDW . hmlotlh5bm . AQHandles ) ; } } { if ( rtDW .
lgovxjzz5e . AQHandles ) { sdiTerminateStreaming ( & rtDW . lgovxjzz5e .
AQHandles ) ; } } { if ( rtDW . dkoje3nlmk . AQHandles ) {
sdiTerminateStreaming ( & rtDW . dkoje3nlmk . AQHandles ) ; } } { if ( rtDW .
hj3h3tskaf . AQHandles ) { sdiTerminateStreaming ( & rtDW . hj3h3tskaf .
AQHandles ) ; } } { if ( rtDW . cn4cqyqs1h . AQHandles ) {
sdiTerminateStreaming ( & rtDW . cn4cqyqs1h . AQHandles ) ; } } } static void
mr_UAV_Test_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_UAV_Test_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_UAV_Test_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_UAV_Test_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_UAV_Test_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_UAV_Test_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( real_T ) bitVal ) ) ; } static uint_T
mr_UAV_Test_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) ; static uint_T
mr_UAV_Test_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_UAV_Test_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_UAV_Test_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_UAV_Test_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_UAV_Test_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_UAV_Test_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_UAV_Test_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
real_T ) fieldVal ) ) ; } static uint_T
mr_UAV_Test_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static uint_T
mr_UAV_Test_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) { const uint_T
fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber ( srcArray
, i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u ) ; }
mxArray * mr_UAV_Test_GetDWork ( ) { static const char_T * ssDWFieldNames [ 3
] = { "rtB" , "rtDW" , "NULL_PrevZCX" , } ; mxArray * ssDW =
mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_UAV_Test_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) & ( rtB ) ,
sizeof ( rtB ) ) ; { static const char_T * rtdwDataFieldNames [ 14 ] = {
"rtDW.c3zoqm3ek0" , "rtDW.a1y4rhv5lu" , "rtDW.eqsas3l3r2" , "rtDW.gnviqiqrwj"
, "rtDW.hdlxlx4cyh" , "rtDW.a5dgdf4x33" , "rtDW.m2byiavbd3" ,
"rtDW.cewk5aac1w" , "rtDW.d4iqeyqmip" , "rtDW.afbl01xbna" , "rtDW.jathlujjus"
, "rtDW.diciq4bwp5" , "rtDW.bwgeet51js" , "rtDW.da34mwshey" , } ; mxArray *
rtdwData = mxCreateStructMatrix ( 1 , 1 , 14 , rtdwDataFieldNames ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 0 , ( const void * ) & ( rtDW
. c3zoqm3ek0 ) , sizeof ( rtDW . c3zoqm3ek0 ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void * ) & ( rtDW
. a1y4rhv5lu ) , sizeof ( rtDW . a1y4rhv5lu ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void * ) & ( rtDW
. eqsas3l3r2 ) , sizeof ( rtDW . eqsas3l3r2 ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void * ) & ( rtDW
. gnviqiqrwj ) , sizeof ( rtDW . gnviqiqrwj ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void * ) & ( rtDW
. hdlxlx4cyh ) , sizeof ( rtDW . hdlxlx4cyh ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void * ) & ( rtDW
. a5dgdf4x33 ) , sizeof ( rtDW . a5dgdf4x33 ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void * ) & ( rtDW
. m2byiavbd3 ) , sizeof ( rtDW . m2byiavbd3 ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void * ) & ( rtDW
. cewk5aac1w ) , sizeof ( rtDW . cewk5aac1w ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void * ) & ( rtDW
. d4iqeyqmip ) , sizeof ( rtDW . d4iqeyqmip ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void * ) & ( rtDW
. afbl01xbna ) , sizeof ( rtDW . afbl01xbna ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const void * ) & (
rtDW . jathlujjus ) , sizeof ( rtDW . jathlujjus ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const void * ) & (
rtDW . diciq4bwp5 ) , sizeof ( rtDW . diciq4bwp5 ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const void * ) & (
rtDW . bwgeet51js ) , sizeof ( rtDW . bwgeet51js ) ) ;
mr_UAV_Test_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const void * ) & (
rtDW . da34mwshey ) , sizeof ( rtDW . da34mwshey ) ) ; mxSetFieldByNumber (
ssDW , 0 , 1 , rtdwData ) ; } return ssDW ; } void mr_UAV_Test_SetDWork (
const mxArray * ssDW ) { ( void ) ssDW ; mr_UAV_Test_restoreDataFromMxArray (
( void * ) & ( rtB ) , ssDW , 0 , 0 , sizeof ( rtB ) ) ; { const mxArray *
rtdwData = mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . c3zoqm3ek0 ) ,
rtdwData , 0 , 0 , sizeof ( rtDW . c3zoqm3ek0 ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . a1y4rhv5lu ) ,
rtdwData , 0 , 1 , sizeof ( rtDW . a1y4rhv5lu ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . eqsas3l3r2 ) ,
rtdwData , 0 , 2 , sizeof ( rtDW . eqsas3l3r2 ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . gnviqiqrwj ) ,
rtdwData , 0 , 3 , sizeof ( rtDW . gnviqiqrwj ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . hdlxlx4cyh ) ,
rtdwData , 0 , 4 , sizeof ( rtDW . hdlxlx4cyh ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . a5dgdf4x33 ) ,
rtdwData , 0 , 5 , sizeof ( rtDW . a5dgdf4x33 ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . m2byiavbd3 ) ,
rtdwData , 0 , 6 , sizeof ( rtDW . m2byiavbd3 ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . cewk5aac1w ) ,
rtdwData , 0 , 7 , sizeof ( rtDW . cewk5aac1w ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . d4iqeyqmip ) ,
rtdwData , 0 , 8 , sizeof ( rtDW . d4iqeyqmip ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . afbl01xbna ) ,
rtdwData , 0 , 9 , sizeof ( rtDW . afbl01xbna ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . jathlujjus ) ,
rtdwData , 0 , 10 , sizeof ( rtDW . jathlujjus ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . diciq4bwp5 ) ,
rtdwData , 0 , 11 , sizeof ( rtDW . diciq4bwp5 ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . bwgeet51js ) ,
rtdwData , 0 , 12 , sizeof ( rtDW . bwgeet51js ) ) ;
mr_UAV_Test_restoreDataFromMxArray ( ( void * ) & ( rtDW . da34mwshey ) ,
rtdwData , 0 , 13 , sizeof ( rtDW . da34mwshey ) ) ; } } mxArray *
mr_UAV_Test_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 5 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char_T * blockType [ 5 ] = { "MATLABSystem" , "MATLABSystem" , "MATLABSystem"
, "MATLABSystem" , "MATLABSystem" , } ; static const char_T * blockPath [ 5 ]
= { "UAV_Test/Coordinate Transformation Conversion" ,
"UAV_Test/UAV Animation" , "UAV_Test/UAV Guidance Model/ComputeDerivative" ,
"UAV_Test/UAV Guidance Model/StateVector2Struct" ,
"UAV_Test/UAV Waypoint Follower" , } ; static const int reason [ 5 ] = { 6 ,
6 , 6 , 6 , 6 , } ; for ( subs [ 0 ] = 0 ; subs [ 0 ] < 5 ; ++ ( subs [ 0 ] )
) { subs [ 1 ] = 0 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ;
mxSetCell ( data , offset , mxCreateString ( blockType [ subs [ 0 ] ] ) ) ;
subs [ 1 ] = 1 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ;
mxSetCell ( data , offset , mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ;
subs [ 1 ] = 2 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ;
mxSetCell ( data , offset , mxCreateDoubleScalar ( ( real_T ) reason [ subs [
0 ] ] ) ) ; } } return data ; } void MdlInitializeSizes ( void ) {
ssSetNumContStates ( rtS , 8 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ;
ssSetNumY ( rtS , 0 ) ; ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS
, 0 ) ; ssSetNumSampleTimes ( rtS , 3 ) ; ssSetNumBlocks ( rtS , 46 ) ;
ssSetNumBlockIO ( rtS , 12 ) ; ssSetNumBlockParams ( rtS , 23 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 0.01 ) ; ssSetSampleTime ( rtS , 2 , 0.1 ) ;
ssSetOffsetTime ( rtS , 0 , 0.0 ) ; ssSetOffsetTime ( rtS , 1 , 0.0 ) ;
ssSetOffsetTime ( rtS , 2 , 0.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 3397064563U ) ; ssSetChecksumVal ( rtS , 1 ,
3118233158U ) ; ssSetChecksumVal ( rtS , 2 , 2192167616U ) ; ssSetChecksumVal
( rtS , 3 , 1297540883U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; static struct _ssBlkInfo2 blkInfo2 ;
static struct _ssBlkInfoSLSize blkInfoSLSize ; ( void ) memset ( ( char_T * )
rtS , 0 , sizeof ( SimStruct ) ) ; ( void ) memset ( ( char_T * ) & mdlInfo ,
0 , sizeof ( struct _ssMdlInfo ) ) ; ( void ) memset ( ( char_T * ) &
blkInfo2 , 0 , sizeof ( struct _ssBlkInfo2 ) ) ; ( void ) memset ( ( char_T *
) & blkInfoSLSize , 0 , sizeof ( struct _ssBlkInfoSLSize ) ) ;
ssSetBlkInfo2Ptr ( rtS , & blkInfo2 ) ; ssSetBlkInfoSLSizePtr ( rtS , &
blkInfoSLSize ) ; ssSetMdlInfoPtr ( rtS , & mdlInfo ) ; ssSetExecutionInfo (
rtS , executionInfo ) ; slsaAllocOPModelData ( rtS ) ; { static time_T
mdlPeriod [ NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ;
static time_T mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [
NSAMPLE_TIMES ] ; static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static
boolean_T mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T
mdlPerTaskSampleHits [ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T
mdlTimeOfNextSampleHit [ NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i <
NSAMPLE_TIMES ; i ++ ) { mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ;
mdlTaskTimes [ i ] = 0.0 ; mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } }
ssSetSampleTimePtr ( rtS , & mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , &
mdlOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ;
ssSetTPtr ( rtS , & mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , &
mdlSampleHits [ 0 ] ) ; ssSetTNextWasAdjustedPtr ( rtS , &
mdlTNextWasAdjustedPtr [ 0 ] ) ; ssSetPerTaskSampleHitsPtr ( rtS , &
mdlPerTaskSampleHits [ 0 ] ) ; ssSetTimeOfNextSampleHitPtr ( rtS , &
mdlTimeOfNextSampleHit [ 0 ] ) ; } ssSetSolverMode ( rtS ,
SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS , ( ( void * ) & rtB ) ) ;
( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof ( B ) ) ; } { real_T * x
= ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ; ( void ) memset ( ( void
* ) x , 0 , sizeof ( X ) ) ; } { void * dwork = ( void * ) & rtDW ;
ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork , 0 , sizeof ( DW )
) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset ( ( char_T * ) &
dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS , & dtInfo ) ;
dtInfo . numDataTypes = 32 ; dtInfo . dataTypeSizes = & rtDataTypeSizes [ 0 ]
; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ; dtInfo . BTransTable = &
rtBTransTable ; dtInfo . PTransTable = & rtPTransTable ; dtInfo .
dataTypeInfoTable = rtDataTypeInfoTable ; } UAV_Test_InitializeDataMapInfo (
) ; ssSetIsRapidAcceleratorActive ( rtS , true ) ; ssSetRootSS ( rtS , rtS )
; ssSetVersion ( rtS , SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS ,
"UAV_Test" ) ; ssSetPath ( rtS , "UAV_Test" ) ; ssSetTStart ( rtS , 0.0 ) ;
ssSetTFinal ( rtS , 100.0 ) ; ssSetStepSize ( rtS , 0.01 ) ;
ssSetFixedStepSize ( rtS , 0.01 ) ; { static RTWLogInfo rt_DataLoggingInfo ;
rt_DataLoggingInfo . loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 8 } ;
static int_T rt_LoggedStateNumDimensions [ ] = { 1 } ; static int_T
rt_LoggedStateDimensions [ ] = { 8 } ; static boolean_T
rt_LoggedStateIsVarDims [ ] = { 0 } ; static BuiltInDTypeId
rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE } ; static int_T
rt_LoggedStateComplexSignals [ ] = { 0 } ; static RTWPreprocessingFcnPtr
rt_LoggingStatePreprocessingFcnPtrs [ ] = { ( NULL ) } ; static const char_T
* rt_LoggedStateLabels [ ] = { "CSTATE" } ; static const char_T *
rt_LoggedStateBlockNames [ ] = { "UAV_Test/UAV Guidance Model/Integrator" } ;
static const char_T * rt_LoggedStateNames [ ] = { "" } ; static boolean_T
rt_LoggedStateCrossMdlRef [ ] = { 0 } ; static RTWLogDataTypeConvert
rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 ,
1.0 , 0 , 0.0 } } ; static int_T rt_LoggedStateIdxList [ ] = { 0 } ; static
RTWLogSignalInfo rt_LoggedStateSignalInfo = { 1 , rt_LoggedStateWidths ,
rt_LoggedStateNumDimensions , rt_LoggedStateDimensions ,
rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 1 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . dxenv44p1n [ 0 ] ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"xFinal" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static boolean_T contStatesDisabled [ 8 ] ;
static ssNonContDerivSigInfo nonContDerivSigInfo [ 2 ] = { { 1 * sizeof (
FixedWingControlBus ) , ( char * ) ( & rtB . levrkdc53u ) , ( NULL ) } , { 1
* sizeof ( FixedWingEnvironmentBus ) , ( char * ) ( & rtB . i2ayzuafga ) , (
NULL ) } } ; ssSetNumNonContDerivSigInfos ( rtS , 2 ) ;
ssSetNonContDerivSigInfos ( rtS , nonContDerivSigInfo ) ; ssSetSolverInfo (
rtS , & slvrInfo ) ; ssSetSolverName ( rtS , "ode3" ) ;
ssSetVariableStepSolver ( rtS , 0 ) ; ssSetSolverConsistencyChecking ( rtS ,
0 ) ; ssSetSolverAdaptiveZcDetection ( rtS , 0 ) ;
ssSetSolverRobustResetMethod ( rtS , 0 ) ; ssSetSolverStateProjection ( rtS ,
0 ) ; ssSetSolverMassMatrixType ( rtS , ( ssMatrixType ) 0 ) ;
ssSetSolverMassMatrixNzMax ( rtS , 0 ) ; ssSetModelOutputs ( rtS , MdlOutputs
) ; ssSetModelUpdate ( rtS , MdlUpdate ) ; ssSetModelDerivatives ( rtS ,
MdlDerivatives ) ; ssSetTNextTid ( rtS , INT_MIN ) ; ssSetTNext ( rtS ,
rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ; ssSetNumNonsampledZCs ( rtS ,
0 ) ; ssSetContStateDisabled ( rtS , contStatesDisabled ) ; }
ssSetChecksumVal ( rtS , 0 , 3397064563U ) ; ssSetChecksumVal ( rtS , 1 ,
3118233158U ) ; ssSetChecksumVal ( rtS , 2 , 2192167616U ) ; ssSetChecksumVal
( rtS , 3 , 1297540883U ) ; { static const sysRanDType rtAlwaysEnabled =
SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo rt_ExtModeInfo ; static const
sysRanDType * systemRan [ 7 ] ; gblRTWExtModeInfo = & rt_ExtModeInfo ;
ssSetRTWExtModeInfo ( rtS , & rt_ExtModeInfo ) ;
rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo , systemRan ) ;
systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = & rtAlwaysEnabled ;
systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = & rtAlwaysEnabled ;
systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = & rtAlwaysEnabled ;
systemRan [ 6 ] = & rtAlwaysEnabled ; rteiSetModelMappingInfoPtr (
ssGetRTWExtModeInfo ( rtS ) , & ssGetModelMappingInfo ( rtS ) ) ;
rteiSetChecksumsPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetChecksums ( rtS ) )
; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS ) , ssGetTPtr ( rtS ) ) ; }
slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_UAV_Test_GetSimStateDisallowedBlocks ) ; slsaGetWorkFcnForSimTargetOP (
rtS , mr_UAV_Test_GetDWork ) ; slsaSetWorkFcnForSimTargetOP ( rtS ,
mr_UAV_Test_SetDWork ) ; rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if (
ssGetErrorStatus ( rtS ) ) { return rtS ; } return rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 3 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID3 ( tid ) ; }
