#ifndef RTW_HEADER_UAV_Test_types_h_
#define RTW_HEADER_UAV_Test_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_FixedWingControlBus_
#define DEFINED_TYPEDEF_FOR_FixedWingControlBus_
typedef struct { real_T Height ; real_T AirSpeed ; real_T RollAngle ; }
FixedWingControlBus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_FixedWingEnvironmentBus_
#define DEFINED_TYPEDEF_FOR_FixedWingEnvironmentBus_
typedef struct { real_T WindNorth ; real_T WindEast ; real_T WindDown ;
real_T Gravity ; } FixedWingEnvironmentBus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_FixedWingStateBus_
#define DEFINED_TYPEDEF_FOR_FixedWingStateBus_
typedef struct { real_T North ; real_T East ; real_T Height ; real_T AirSpeed
; real_T HeadingAngle ; real_T FlightPathAngle ; real_T RollAngle ; real_T
RollAngleRate ; } FixedWingStateBus ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_pAzQu3LPpISTV2tr3rS1KE_
#define DEFINED_TYPEDEF_FOR_struct_pAzQu3LPpISTV2tr3rS1KE_
typedef struct { real_T PDRoll [ 2 ] ; real_T PHeight ; real_T
PFlightPathAngle ; real_T PAirSpeed ; real_T FlightPathAngleLimits [ 2 ] ; }
struct_pAzQu3LPpISTV2tr3rS1KE ;
#endif
#ifndef struct_tag_2PsGMppoK4e2vdwpogf6iH
#define struct_tag_2PsGMppoK4e2vdwpogf6iH
struct tag_2PsGMppoK4e2vdwpogf6iH { int32_T isInitialized ; } ;
#endif
#ifndef typedef_aqsz1cuko0
#define typedef_aqsz1cuko0
typedef struct tag_2PsGMppoK4e2vdwpogf6iH aqsz1cuko0 ;
#endif
#ifndef struct_tag_L5QeHZ9f6Ik2vhPbuWGr5E
#define struct_tag_L5QeHZ9f6Ik2vhPbuWGr5E
struct tag_L5QeHZ9f6Ik2vhPbuWGr5E { int32_T __dummy ; } ;
#endif
#ifndef typedef_pe15cc1ffs
#define typedef_pe15cc1ffs
typedef struct tag_L5QeHZ9f6Ik2vhPbuWGr5E pe15cc1ffs ;
#endif
#ifndef struct_tag_B2I88SlEJLUpqMQuJlpJuH
#define struct_tag_B2I88SlEJLUpqMQuJlpJuH
struct tag_B2I88SlEJLUpqMQuJlpJuH { int32_T isInitialized ; pe15cc1ffs
SampleTimeHandler ; } ;
#endif
#ifndef typedef_fnellbpznb
#define typedef_fnellbpznb
typedef struct tag_B2I88SlEJLUpqMQuJlpJuH fnellbpznb ;
#endif
#ifndef struct_tag_NT0wpGJQJLDjEJaEnOcGJ
#define struct_tag_NT0wpGJQJLDjEJaEnOcGJ
struct tag_NT0wpGJQJLDjEJaEnOcGJ { real_T North ; real_T East ; real_T Height
; real_T AirSpeed ; real_T HeadingAngle ; real_T FlightPathAngle ; real_T
RollAngle ; real_T RollAngleRate ; } ;
#endif
#ifndef typedef_ctkrjfhwiy
#define typedef_ctkrjfhwiy
typedef struct tag_NT0wpGJQJLDjEJaEnOcGJ ctkrjfhwiy ;
#endif
#ifndef struct_tag_TJETJTpvQNmRuytKNGMGeE
#define struct_tag_TJETJTpvQNmRuytKNGMGeE
struct tag_TJETJTpvQNmRuytKNGMGeE { int32_T isInitialized ; ctkrjfhwiy
OutputTemplate ; } ;
#endif
#ifndef typedef_ojbkccld5t
#define typedef_ojbkccld5t
typedef struct tag_TJETJTpvQNmRuytKNGMGeE ojbkccld5t ;
#endif
#ifndef struct_tag_AUVfKAT5f7cwSOe88fPiT
#define struct_tag_AUVfKAT5f7cwSOe88fPiT
struct tag_AUVfKAT5f7cwSOe88fPiT { real_T PDRoll [ 2 ] ; real_T PHeight ;
real_T PFlightPathAngle ; real_T PAirSpeed ; real_T FlightPathAngleLimits [ 2
] ; } ;
#endif
#ifndef typedef_cotsuh1b0c
#define typedef_cotsuh1b0c
typedef struct tag_AUVfKAT5f7cwSOe88fPiT cotsuh1b0c ;
#endif
#ifndef struct_tag_nU7qbK1fQOArJdjIs1D8rE
#define struct_tag_nU7qbK1fQOArJdjIs1D8rE
struct tag_nU7qbK1fQOArJdjIs1D8rE { cotsuh1b0c Configuration ; } ;
#endif
#ifndef typedef_lu1oubdn1n
#define typedef_lu1oubdn1n
typedef struct tag_nU7qbK1fQOArJdjIs1D8rE lu1oubdn1n ;
#endif
#ifndef struct_tag_kTsMi7joryhsNhvvXc4rfE
#define struct_tag_kTsMi7joryhsNhvvXc4rfE
struct tag_kTsMi7joryhsNhvvXc4rfE { int32_T isInitialized ; lu1oubdn1n
ModelImpl ; } ;
#endif
#ifndef typedef_ncubee03tu
#define typedef_ncubee03tu
typedef struct tag_kTsMi7joryhsNhvvXc4rfE ncubee03tu ;
#endif
#ifndef struct_tag_BlgwLpgj2bjudmbmVKWwDE
#define struct_tag_BlgwLpgj2bjudmbmVKWwDE
struct tag_BlgwLpgj2bjudmbmVKWwDE { uint32_T f1 [ 8 ] ; } ;
#endif
#ifndef typedef_lafze4nfdx
#define typedef_lafze4nfdx
typedef struct tag_BlgwLpgj2bjudmbmVKWwDE lafze4nfdx ;
#endif
#ifndef struct_tag_YbgMT3ZSflXa3JfuFnc1L
#define struct_tag_YbgMT3ZSflXa3JfuFnc1L
struct tag_YbgMT3ZSflXa3JfuFnc1L { int32_T isInitialized ; lafze4nfdx
inputVarSize [ 3 ] ; real_T LookaheadDistance ; real_T WaypointIndex ; real_T
NumWaypoints ; real_T WaypointsInternal [ 3 ] ; boolean_T LastWaypointFlag ;
boolean_T StartFlag ; real_T InitialPose [ 4 ] ; real_T LookaheadFactor ;
uint8_T LookaheadDistFlag ; } ;
#endif
#ifndef typedef_gqnstspnxw
#define typedef_gqnstspnxw
typedef struct tag_YbgMT3ZSflXa3JfuFnc1L gqnstspnxw ;
#endif
#ifndef SS_UINT64
#define SS_UINT64 26
#endif
#ifndef SS_INT64
#define SS_INT64 27
#endif
typedef struct P_ P ;
#endif
