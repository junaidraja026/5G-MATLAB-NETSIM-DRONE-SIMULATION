fileID=fopen('mobility.txt','w');
for i=1:10001,fprintf(fileID,'$time %.2f \"$node_(0) %.2f %.2f %.2f\"\n',tout(i),North(i),East(i),Height(i));endfclose(fileID),
end