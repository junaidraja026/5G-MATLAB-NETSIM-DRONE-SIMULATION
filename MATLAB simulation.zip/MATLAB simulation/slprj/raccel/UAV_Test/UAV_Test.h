#ifndef RTW_HEADER_UAV_Test_h_
#define RTW_HEADER_UAV_Test_h_
#ifndef UAV_Test_COMMON_INCLUDES_
#define UAV_Test_COMMON_INCLUDES_
#include <stdlib.h>
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "UAV_Test_types.h"
#include <stddef.h>
#include "rt_nonfinite.h"
#include "rtGetNaN.h"
#include "rtw_modelmap_simtarget.h"
#include "rt_defines.h"
#include <string.h>
#define MODEL_NAME UAV_Test
#define NSAMPLE_TIMES (4) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (12) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (8)   
#elif NCSTATES != 8
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { FixedWingStateBus jaclmxlu53 ; FixedWingStateBus mlb0e0sr0w
; FixedWingEnvironmentBus i2ayzuafga ; FixedWingControlBus levrkdc53u ;
real_T nq0zt43ydn ; real_T c5mxrwdcg5 ; real_T acfna5rqkg ; real_T dpgfngmojw
; real_T jn4qlnqquf [ 8 ] ; real_T if42dzhbz4 [ 4 ] ; uint8_T fphsuwgig0 ; }
B ; typedef struct { gqnstspnxw c3zoqm3ek0 ; ojbkccld5t a1y4rhv5lu ;
ncubee03tu eqsas3l3r2 ; FixedWingControlBus gnviqiqrwj ; fnellbpznb
hdlxlx4cyh ; struct { void * AQHandles ; } ogvugh2h0k ; struct { void *
AQHandles ; } j1zd3xo5ku ; struct { void * AQHandles ; } hmlotlh5bm ; struct
{ void * AQHandles ; } lgovxjzz5e ; struct { void * AQHandles ; } dkoje3nlmk
; struct { void * AQHandles ; } hj3h3tskaf ; struct { void * AQHandles ; }
cn4cqyqs1h ; int32_T a5dgdf4x33 ; aqsz1cuko0 m2byiavbd3 ; uint8_T cewk5aac1w
; boolean_T d4iqeyqmip ; boolean_T afbl01xbna ; boolean_T jathlujjus ;
boolean_T diciq4bwp5 ; boolean_T bwgeet51js ; boolean_T da34mwshey ; } DW ;
typedef struct { real_T dxenv44p1n [ 8 ] ; } X ; typedef struct { real_T
dxenv44p1n [ 8 ] ; } XDot ; typedef struct { boolean_T dxenv44p1n [ 8 ] ; }
XDis ; typedef struct { rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ; struct
P_ { real_T HeadingConrol_PHeadingAngle ; real_T Integrator_IC [ 8 ] ; real_T
Gain1_Gain ; real_T Gain2_Gain ; real_T Saturation2_UpperSat ; real_T
Saturation2_LowerSat ; real_T Gain_Gain ; real_T Constant2_Value ; real_T
LookaheadDistance_Value ; real_T Waypoints_Value [ 3 ] ; real_T
Constant_Value ; real_T Constant1_Value ; real_T Constant2_Value_dde35bhip2 ;
real_T Constant3_Value ; } ; extern const char_T * RT_MEMORY_ALLOCATION_ERROR
; extern B rtB ; extern X rtX ; extern DW rtDW ; extern P rtP ; extern
mxArray * mr_UAV_Test_GetDWork ( ) ; extern void mr_UAV_Test_SetDWork ( const
mxArray * ssDW ) ; extern mxArray * mr_UAV_Test_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo * UAV_Test_GetCAPIStaticMap (
void ) ; extern SimStruct * const rtS ; extern const int_T gblNumToFiles ;
extern const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ;
extern rtInportTUtable * gblInportTUtables ; extern const char *
gblInportFileName ; extern const int_T gblNumRootInportBlks ; extern const
int_T gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ;
extern const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [
] ; extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
