#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "UAV_Test_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)
#ifndef SS_UINT64
#define SS_UINT64 26
#endif
#ifndef SS_INT64
#define SS_INT64 27
#endif
#else
#include "builtin_typeid_types.h"
#include "UAV_Test.h"
#include "UAV_Test_capi.h"
#include "UAV_Test_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , TARGET_STRING (
"UAV_Test/Heading Conrol/is_active_c2_UAV_Test" ) , TARGET_STRING (
"is_active_c2_UAV_Test" ) , 0 , 0 , 0 , 0 , 0 } , { 1 , 0 , TARGET_STRING (
"UAV_Test/Gain" ) , TARGET_STRING ( "" ) , 0 , 1 , 0 , 0 , 1 } , { 2 , 0 ,
TARGET_STRING (
"UAV_Test/SigConversion_InsertedFor_Bus Selector1_at_outport_0" ) ,
TARGET_STRING ( "North" ) , 0 , 1 , 0 , 0 , 1 } , { 3 , 0 , TARGET_STRING (
"UAV_Test/SigConversion_InsertedFor_Bus Selector1_at_outport_1" ) ,
TARGET_STRING ( "East" ) , 0 , 1 , 0 , 0 , 1 } , { 4 , 0 , TARGET_STRING (
"UAV_Test/SigConversion_InsertedFor_Bus Selector1_at_outport_2" ) ,
TARGET_STRING ( "Height" ) , 0 , 1 , 0 , 0 , 1 } , { 5 , 0 , TARGET_STRING (
"UAV_Test/Rate Transition1" ) , TARGET_STRING ( "" ) , 0 , 2 , 0 , 0 , 0 } ,
{ 6 , 0 , TARGET_STRING ( "UAV_Test/Rate Transition2" ) , TARGET_STRING ( ""
) , 0 , 3 , 0 , 0 , 2 } , { 7 , 1 , TARGET_STRING (
"UAV_Test/Coordinate Transformation Conversion" ) , TARGET_STRING (
"Rotation" ) , 0 , 1 , 2 , 0 , 1 } , { 8 , 6 , TARGET_STRING (
"UAV_Test/UAV Waypoint Follower" ) , TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0
} , { 9 , 4 , TARGET_STRING ( "UAV_Test/UAV Guidance Model/ComputeDerivative"
) , TARGET_STRING ( "" ) , 0 , 1 , 3 , 0 , 1 } , { 10 , 5 , TARGET_STRING (
"UAV_Test/UAV Guidance Model/StateVector2Struct" ) , TARGET_STRING ( "" ) , 0
, 2 , 0 , 0 , 1 } , { 11 , 0 , TARGET_STRING (
"UAV_Test/Windless/Bus Creator" ) , TARGET_STRING ( "" ) , 0 , 4 , 0 , 0 , 0
} , { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_BlockParameters rtBlockParameters [ ] = { { 12 , TARGET_STRING (
"UAV_Test/Heading Conrol" ) , TARGET_STRING ( "PHeadingAngle" ) , 1 , 0 , 0 }
, { 13 , TARGET_STRING ( "UAV_Test/Constant2" ) , TARGET_STRING ( "Value" ) ,
1 , 0 , 0 } , { 14 , TARGET_STRING ( "UAV_Test/Lookahead Distance" ) ,
TARGET_STRING ( "Value" ) , 1 , 0 , 0 } , { 15 , TARGET_STRING (
"UAV_Test/Waypoints" ) , TARGET_STRING ( "Value" ) , 1 , 4 , 0 } , { 16 ,
TARGET_STRING ( "UAV_Test/Gain" ) , TARGET_STRING ( "Gain" ) , 1 , 0 , 0 } ,
{ 17 , TARGET_STRING ( "UAV_Test/Gain1" ) , TARGET_STRING ( "Gain" ) , 1 , 0
, 0 } , { 18 , TARGET_STRING ( "UAV_Test/Gain2" ) , TARGET_STRING ( "Gain" )
, 1 , 0 , 0 } , { 19 , TARGET_STRING ( "UAV_Test/Saturation2" ) ,
TARGET_STRING ( "UpperLimit" ) , 1 , 0 , 0 } , { 20 , TARGET_STRING (
"UAV_Test/Saturation2" ) , TARGET_STRING ( "LowerLimit" ) , 1 , 0 , 0 } , {
21 , TARGET_STRING ( "UAV_Test/UAV Guidance Model/Integrator" ) ,
TARGET_STRING ( "InitialCondition" ) , 1 , 5 , 0 } , { 22 , TARGET_STRING (
"UAV_Test/Windless/Constant" ) , TARGET_STRING ( "Value" ) , 1 , 0 , 0 } , {
23 , TARGET_STRING ( "UAV_Test/Windless/Constant1" ) , TARGET_STRING (
"Value" ) , 1 , 0 , 0 } , { 24 , TARGET_STRING (
"UAV_Test/Windless/Constant2" ) , TARGET_STRING ( "Value" ) , 1 , 0 , 0 } , {
25 , TARGET_STRING ( "UAV_Test/Windless/Constant3" ) , TARGET_STRING (
"Value" ) , 1 , 0 , 0 } , { 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 } } ; static
int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static const rtwCAPI_Signals
rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ;
static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0 , 0 , ( NULL ) , (
NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_ModelParameters
rtModelParameters [ ] = { { 0 , ( NULL ) , 0 , 0 , 0 } } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtDW . cewk5aac1w , & rtB . dpgfngmojw
, & rtB . nq0zt43ydn , & rtB . c5mxrwdcg5 , & rtB . acfna5rqkg , & rtB .
jaclmxlu53 , & rtB . levrkdc53u , & rtB . if42dzhbz4 [ 0 ] , & rtB .
fphsuwgig0 , & rtB . jn4qlnqquf [ 0 ] , & rtB . mlb0e0sr0w , & rtB .
i2ayzuafga , & rtP . HeadingConrol_PHeadingAngle , & rtP . Constant2_Value ,
& rtP . LookaheadDistance_Value , & rtP . Waypoints_Value [ 0 ] , & rtP .
Gain_Gain , & rtP . Gain1_Gain , & rtP . Gain2_Gain , & rtP .
Saturation2_UpperSat , & rtP . Saturation2_LowerSat , & rtP . Integrator_IC [
0 ] , & rtP . Constant_Value , & rtP . Constant1_Value , & rtP .
Constant2_Value_dde35bhip2 , & rtP . Constant3_Value , } ; static int32_T *
rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { {
"unsigned char" , "uint8_T" , 0 , 0 , sizeof ( uint8_T ) , ( uint8_T )
SS_UINT8 , 0 , 0 , 0 } , { "double" , "real_T" , 0 , 0 , sizeof ( real_T ) ,
( uint8_T ) SS_DOUBLE , 0 , 0 , 0 } , { "struct" , "FixedWingStateBus" , 8 ,
1 , sizeof ( FixedWingStateBus ) , ( uint8_T ) SS_STRUCT , 0 , 0 , 0 } , {
"struct" , "FixedWingControlBus" , 3 , 9 , sizeof ( FixedWingControlBus ) , (
uint8_T ) SS_STRUCT , 0 , 0 , 0 } , { "struct" , "FixedWingEnvironmentBus" ,
4 , 12 , sizeof ( FixedWingEnvironmentBus ) , ( uint8_T ) SS_STRUCT , 0 , 0 ,
0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , { "North" , rt_offsetof ( FixedWingStateBus , North ) , 1 , 1 ,
0 } , { "East" , rt_offsetof ( FixedWingStateBus , East ) , 1 , 1 , 0 } , {
"Height" , rt_offsetof ( FixedWingStateBus , Height ) , 1 , 1 , 0 } , {
"AirSpeed" , rt_offsetof ( FixedWingStateBus , AirSpeed ) , 1 , 1 , 0 } , {
"HeadingAngle" , rt_offsetof ( FixedWingStateBus , HeadingAngle ) , 1 , 1 , 0
} , { "FlightPathAngle" , rt_offsetof ( FixedWingStateBus , FlightPathAngle )
, 1 , 1 , 0 } , { "RollAngle" , rt_offsetof ( FixedWingStateBus , RollAngle )
, 1 , 1 , 0 } , { "RollAngleRate" , rt_offsetof ( FixedWingStateBus ,
RollAngleRate ) , 1 , 1 , 0 } , { "Height" , rt_offsetof (
FixedWingControlBus , Height ) , 1 , 1 , 0 } , { "AirSpeed" , rt_offsetof (
FixedWingControlBus , AirSpeed ) , 1 , 1 , 0 } , { "RollAngle" , rt_offsetof
( FixedWingControlBus , RollAngle ) , 1 , 1 , 0 } , { "WindNorth" ,
rt_offsetof ( FixedWingEnvironmentBus , WindNorth ) , 1 , 1 , 0 } , {
"WindEast" , rt_offsetof ( FixedWingEnvironmentBus , WindEast ) , 1 , 1 , 0 }
, { "WindDown" , rt_offsetof ( FixedWingEnvironmentBus , WindDown ) , 1 , 1 ,
0 } , { "Gravity" , rt_offsetof ( FixedWingEnvironmentBus , Gravity ) , 1 , 1
, 0 } } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 0 , 2 , 0 } , {
rtwCAPI_MATRIX_COL_MAJOR , 2 , 2 , 0 } , { rtwCAPI_MATRIX_COL_MAJOR , 4 , 2 ,
0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , { rtwCAPI_VECTOR , 4 , 2 , 0 } } ;
static const uint_T rtDimensionArray [ ] = { 1 , 1 , 4 , 1 , 8 , 1 , 1 , 3 }
; static const real_T rtcapiStoredFloats [ ] = { 0.01 , 0.0 , 0.1 } ; static
const rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , ( boolean_T ) 0 } , } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] , (
int8_T ) 1 , ( uint8_T ) 0 } , { ( const void * ) & rtcapiStoredFloats [ 1 ]
, ( const void * ) & rtcapiStoredFloats [ 1 ] , ( int8_T ) 0 , ( uint8_T ) 0
} , { ( const void * ) & rtcapiStoredFloats [ 2 ] , ( const void * ) &
rtcapiStoredFloats [ 1 ] , ( int8_T ) 2 , ( uint8_T ) 0 } } ; static
rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 12 ,
rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 14 ,
rtModelParameters , 0 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 3397064563U , 3118233158U , 2192167616U , 1297540883U } , ( NULL ) , 0 ,
( boolean_T ) 0 , rt_LoggedStateIdxList } ; const
rtwCAPI_ModelMappingStaticInfo * UAV_Test_GetCAPIStaticMap ( void ) { return
& mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void UAV_Test_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion ( ( *
rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void UAV_Test_host_InitializeDataMapInfo ( UAV_Test_host_DataMapInfo_T *
dataMap , const char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , ( NULL ) ) ; rtwCAPI_SetPath
( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , ( NULL ) )
; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
